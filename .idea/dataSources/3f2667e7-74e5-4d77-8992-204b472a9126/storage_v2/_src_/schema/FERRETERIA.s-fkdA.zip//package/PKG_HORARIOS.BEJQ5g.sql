create PACKAGE PKG_HORARIOS AS
    FUNCTION fn_listar_horarios RETURN SYS_REFCURSOR;
    FUNCTION fn_obtener_horario(p_id NUMBER) RETURN SYS_REFCURSOR;
    FUNCTION fn_listar_horarios_por_empleado(p_id_empleado NUMBER) RETURN SYS_REFCURSOR;
    PROCEDURE sp_insertar_horario(
        p_id_empleado NUMBER,
        p_fecha DATE,
        p_hora_entrada NUMBER,
        p_hora_salida NUMBER,
        p_observaciones VARCHAR2 DEFAULT NULL,
        p_id_horario OUT NUMBER
    );
    PROCEDURE sp_actualizar_horario(
        p_id NUMBER,
        p_fecha DATE,
        p_hora_entrada NUMBER,
        p_hora_salida NUMBER,
        p_observaciones VARCHAR2 DEFAULT NULL
    );
    PROCEDURE sp_eliminar_horario(p_id NUMBER);
END PKG_HORARIOS;
/

