create trigger TRG_FACTURA_ACTUALIZAR_TOTAL
    instead of insert or update or delete
    on DETALLEFACTURA
    for each row
    COMPOUND TRIGGER
  TYPE t_ids IS TABLE OF NUMBER INDEX BY PLS_INTEGER;
  g_ids t_ids;

  PROCEDURE add_id(p_id NUMBER) IS
BEGIN
    IF p_id IS NOT NULL THEN
      g_ids(g_ids.COUNT+1) := p_id;
    END IF;
  END;

  BEFORE STATEMENT IS BEGIN g_ids.DELETE; END BEFORE STATEMENT;

  AFTER EACH ROW IS
  BEGIN
    IF INSERTING OR UPDATING THEN
      add_id(:NEW.IdFactura);
    ELSIF DELETING THEN
      add_id(:OLD.IdFactura);
    END IF;
  END AFTER EACH ROW;

  AFTER STATEMENT IS
  BEGIN
    IF g_ids.COUNT > 0 THEN
      FOR i IN 1..g_ids.COUNT LOOP
        DECLARE v_sub NUMBER(12,2); v_imp NUMBER(12,2); v_tot NUMBER(12,2);
        BEGIN
    SELECT NVL(SUM((precioUni * cantidad) - descuento_item), 0)
            INTO v_sub
    FROM detalleFactura
           WHERE IdFactura = g_ids(i);
          v_imp := v_sub * 0.15;
          v_tot := v_sub + v_imp;
    UPDATE Factura
             SET subtotal = v_sub,
                 impuesto = v_imp,
                 total = v_tot,
        fecha_modificacion = SYSDATE
           WHERE IdFactura = g_ids(i);
        END;
      END LOOP;
    END IF;
  END AFTER STATEMENT;
END;
/

