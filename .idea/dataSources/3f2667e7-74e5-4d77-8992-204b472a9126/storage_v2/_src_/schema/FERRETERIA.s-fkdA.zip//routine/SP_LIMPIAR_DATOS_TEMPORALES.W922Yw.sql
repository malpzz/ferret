create PROCEDURE sp_limpiar_datos_temporales AS
    v_count NUMBER;
BEGIN
    -- Elimina facturas en estado PENDIENTE con mÃƒÂ¡s de 30 dÃƒÂ­as
    DELETE FROM detalleFactura
    WHERE IdFactura IN (
        SELECT IdFactura FROM Factura
        WHERE estado = 'PENDIENTE'
        AND fecha < SYSDATE - 30
    );

    DELETE FROM Factura
    WHERE estado = 'PENDIENTE'
    AND fecha < SYSDATE - 30;

    v_count := SQL%ROWCOUNT;

    COMMIT;
    DBMS_OUTPUT.PUT_LINE('Facturas pendientes eliminadas: ' || v_count);

EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        DBMS_OUTPUT.PUT_LINE('Error al limpiar datos temporales: ' || SQLERRM);
END;
/

