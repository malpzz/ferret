create PACKAGE PKG_FERRETERIA AS
    -- DeclaraciÃƒÂ³n de tipos y constantes
    TYPE t_resultado IS RECORD (
        exito BOOLEAN,
        mensaje VARCHAR2(500)
    );

    -- Procedimientos CRUD para Roles
    PROCEDURE sp_insertar_rol(p_nombre VARCHAR2, p_descripcion VARCHAR2, p_resultado OUT t_resultado);
    PROCEDURE sp_actualizar_rol(p_id NUMBER, p_nombre VARCHAR2, p_descripcion VARCHAR2, p_resultado OUT t_resultado);
    PROCEDURE sp_eliminar_rol(p_id NUMBER, p_resultado OUT t_resultado);
    FUNCTION fn_obtener_rol(p_id NUMBER) RETURN SYS_REFCURSOR;
    FUNCTION fn_listar_roles RETURN SYS_REFCURSOR;

    -- Procedimientos CRUD para Usuarios (CON CURSOR)
    PROCEDURE sp_insertar_usuario(p_nombre_usuario VARCHAR2, p_contrasena VARCHAR2, p_email VARCHAR2,
                                 p_nombre VARCHAR2, p_apellidos VARCHAR2, p_telefono VARCHAR2,
                                 p_id_rol NUMBER, p_resultado OUT t_resultado);
    PROCEDURE sp_actualizar_usuario(p_id NUMBER, p_nombre_usuario VARCHAR2, p_contrasena VARCHAR2,
                                   p_email VARCHAR2, p_nombre VARCHAR2, p_apellidos VARCHAR2,
                                   p_telefono VARCHAR2, p_id_rol NUMBER, p_resultado OUT t_resultado);
    PROCEDURE sp_eliminar_usuario(p_id NUMBER, p_resultado OUT t_resultado);
    PROCEDURE sp_validar_usuarios_activos; -- CON CURSOR
    FUNCTION fn_obtener_usuario(p_id NUMBER) RETURN SYS_REFCURSOR;
    FUNCTION fn_listar_usuarios RETURN SYS_REFCURSOR;

    -- Procedimientos CRUD para Clientes (CON CURSOR)
    PROCEDURE sp_insertar_cliente(p_nombre VARCHAR2, p_apellidos VARCHAR2, p_direccion VARCHAR2,
                                 p_telefono VARCHAR2, p_email VARCHAR2, p_cedula VARCHAR2,
                                 p_tipo_cliente VARCHAR2, p_resultado OUT t_resultado);
    PROCEDURE sp_actualizar_cliente(p_id NUMBER, p_nombre VARCHAR2, p_apellidos VARCHAR2,
                                   p_direccion VARCHAR2, p_telefono VARCHAR2, p_email VARCHAR2,
                                   p_cedula VARCHAR2, p_tipo_cliente VARCHAR2, p_resultado OUT t_resultado);
    PROCEDURE sp_eliminar_cliente(p_id NUMBER, p_resultado OUT t_resultado);
    PROCEDURE sp_actualizar_limites_credito; -- CON CURSOR
    FUNCTION fn_obtener_cliente(p_id NUMBER) RETURN SYS_REFCURSOR;
    FUNCTION fn_listar_clientes RETURN SYS_REFCURSOR;
    -- Wrappers compatibles con JDBC (sin OUT RECORD/BOOLEAN)
    PROCEDURE sp_insertar_cliente_jdbc(p_nombre VARCHAR2, p_apellidos VARCHAR2, p_direccion VARCHAR2,
                                      p_telefono VARCHAR2, p_email VARCHAR2, p_cedula VARCHAR2,
                                      p_tipo_cliente VARCHAR2);
    PROCEDURE sp_actualizar_cliente_jdbc(p_id NUMBER, p_nombre VARCHAR2, p_apellidos VARCHAR2,
                                         p_direccion VARCHAR2, p_telefono VARCHAR2, p_email VARCHAR2,
                                         p_cedula VARCHAR2, p_tipo_cliente VARCHAR2);
    PROCEDURE sp_eliminar_cliente_jdbc(p_id NUMBER);

    -- Procedimientos CRUD para Empleados
    PROCEDURE sp_insertar_empleado(p_nombre VARCHAR2, p_apellidos VARCHAR2, p_direccion VARCHAR2,
                                  p_telefono VARCHAR2, p_email VARCHAR2, p_cedula VARCHAR2,
                                  p_puesto VARCHAR2, p_salario NUMBER, p_resultado OUT t_resultado);
    PROCEDURE sp_actualizar_empleado(p_id NUMBER, p_nombre VARCHAR2, p_apellidos VARCHAR2,
                                    p_direccion VARCHAR2, p_telefono VARCHAR2, p_email VARCHAR2,
                                    p_cedula VARCHAR2, p_puesto VARCHAR2, p_salario NUMBER,
                                    p_resultado OUT t_resultado);
    PROCEDURE sp_eliminar_empleado(p_id NUMBER, p_resultado OUT t_resultado);
    FUNCTION fn_obtener_empleado(p_id NUMBER) RETURN SYS_REFCURSOR;
    FUNCTION fn_listar_empleados RETURN SYS_REFCURSOR;
    -- Wrappers compatibles con JDBC
    PROCEDURE sp_insertar_empleado_jdbc(p_nombre VARCHAR2, p_apellidos VARCHAR2, p_direccion VARCHAR2,
                                        p_telefono VARCHAR2, p_email VARCHAR2, p_cedula VARCHAR2,
                                        p_puesto VARCHAR2, p_salario NUMBER);
    PROCEDURE sp_actualizar_empleado_jdbc(p_id NUMBER, p_nombre VARCHAR2, p_apellidos VARCHAR2,
                                          p_direccion VARCHAR2, p_telefono VARCHAR2, p_email VARCHAR2,
                                          p_cedula VARCHAR2, p_puesto VARCHAR2, p_salario NUMBER);
    PROCEDURE sp_eliminar_empleado_jdbc(p_id NUMBER);

    -- Procedimientos CRUD para Proveedores
    PROCEDURE sp_insertar_proveedor(p_nombre VARCHAR2, p_direccion VARCHAR2, p_telefono VARCHAR2,
                                   p_email VARCHAR2, p_contacto VARCHAR2, p_ruc VARCHAR2,
                                   p_condiciones_pago VARCHAR2, p_resultado OUT t_resultado);
    PROCEDURE sp_actualizar_proveedor(p_id NUMBER, p_nombre VARCHAR2, p_direccion VARCHAR2,
                                     p_telefono VARCHAR2, p_email VARCHAR2, p_contacto VARCHAR2,
                                     p_ruc VARCHAR2, p_condiciones_pago VARCHAR2, p_resultado OUT t_resultado);
    PROCEDURE sp_eliminar_proveedor(p_id NUMBER, p_resultado OUT t_resultado);
    FUNCTION fn_obtener_proveedor(p_id NUMBER) RETURN SYS_REFCURSOR;
    FUNCTION fn_listar_proveedores RETURN SYS_REFCURSOR;
    -- Wrappers compatibles con JDBC
    PROCEDURE sp_insertar_proveedor_jdbc(p_nombre VARCHAR2, p_direccion VARCHAR2, p_telefono VARCHAR2,
                                         p_email VARCHAR2, p_contacto VARCHAR2, p_ruc VARCHAR2,
                                         p_condiciones_pago VARCHAR2);
    PROCEDURE sp_actualizar_proveedor_jdbc(p_id NUMBER, p_nombre VARCHAR2, p_direccion VARCHAR2,
                                           p_telefono VARCHAR2, p_email VARCHAR2, p_contacto VARCHAR2,
                                           p_ruc VARCHAR2, p_condiciones_pago VARCHAR2);
    PROCEDURE sp_eliminar_proveedor_jdbc(p_id NUMBER);

    -- Procedimientos CRUD para Productos (CON CURSOR)
    PROCEDURE sp_insertar_producto(p_nombre VARCHAR2, p_descripcion VARCHAR2, p_codigo VARCHAR2,
                                  p_categoria VARCHAR2, p_marca VARCHAR2, p_precio NUMBER,
                                  p_precio_compra NUMBER, p_unidad_medida VARCHAR2,
                                  p_stock_minimo NUMBER, p_id_proveedor NUMBER, p_resultado OUT t_resultado);
    PROCEDURE sp_actualizar_producto(p_id NUMBER, p_nombre VARCHAR2, p_descripcion VARCHAR2,
                                    p_codigo VARCHAR2, p_categoria VARCHAR2, p_marca VARCHAR2,
                                    p_precio NUMBER, p_precio_compra NUMBER, p_unidad_medida VARCHAR2,
                                    p_stock_minimo NUMBER, p_id_proveedor NUMBER, p_resultado OUT t_resultado);
    PROCEDURE sp_eliminar_producto(p_id NUMBER, p_resultado OUT t_resultado);
    PROCEDURE sp_alertas_stock_minimo; -- CON CURSOR
    FUNCTION fn_obtener_producto(p_id NUMBER) RETURN SYS_REFCURSOR;
    FUNCTION fn_listar_productos RETURN SYS_REFCURSOR;
    -- Wrappers compatibles con JDBC
    PROCEDURE sp_insertar_producto_jdbc(p_nombre VARCHAR2, p_descripcion VARCHAR2, p_codigo VARCHAR2,
                                        p_categoria VARCHAR2, p_marca VARCHAR2, p_precio NUMBER,
                                        p_precio_compra NUMBER, p_unidad_medida VARCHAR2,
                                        p_stock_minimo NUMBER, p_id_proveedor NUMBER);
    PROCEDURE sp_actualizar_producto_jdbc(p_id NUMBER, p_nombre VARCHAR2, p_descripcion VARCHAR2,
                                          p_codigo VARCHAR2, p_categoria VARCHAR2, p_marca VARCHAR2,
                                          p_precio NUMBER, p_precio_compra NUMBER, p_unidad_medida VARCHAR2,
                                          p_stock_minimo NUMBER, p_id_proveedor NUMBER);
    PROCEDURE sp_eliminar_producto_jdbc(p_id NUMBER);

    -- Funciones de consulta con EXPRESIONES REGULARES
    FUNCTION fn_buscar_clientes_por_email(p_patron VARCHAR2) RETURN SYS_REFCURSOR; -- EXPRESIÃƒâ€œN REGULAR
    FUNCTION fn_buscar_productos_por_codigo(p_patron VARCHAR2) RETURN SYS_REFCURSOR; -- EXPRESIÃƒâ€œN REGULAR
    FUNCTION fn_validar_telefonos_empleados RETURN SYS_REFCURSOR; -- EXPRESIÃƒâ€œN REGULAR
    FUNCTION fn_buscar_proveedores_por_ruc(p_patron VARCHAR2) RETURN SYS_REFCURSOR; -- EXPRESIÃƒâ€œN REGULAR

    -- Funciones de reportes
    FUNCTION fn_reporte_ventas_mes(p_mes NUMBER, p_anio NUMBER) RETURN SYS_REFCURSOR;
    FUNCTION fn_productos_mas_vendidos(p_limite NUMBER DEFAULT 10) RETURN SYS_REFCURSOR;
    FUNCTION fn_clientes_mayor_compra RETURN SYS_REFCURSOR;

END PKG_FERRETERIA;
/

