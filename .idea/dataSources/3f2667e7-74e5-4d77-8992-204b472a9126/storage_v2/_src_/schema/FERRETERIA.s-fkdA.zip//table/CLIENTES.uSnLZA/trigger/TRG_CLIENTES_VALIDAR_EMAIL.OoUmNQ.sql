create trigger TRG_CLIENTES_VALIDAR_EMAIL
    before insert or update
    on CLIENTES
    for each row
BEGIN
    -- Valida que el email tenga un formato correcto usando expresiÃƒÂ³n regular
    IF :NEW.email IS NOT NULL AND NOT REGEXP_LIKE(:NEW.email, '^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$') THEN
        RAISE_APPLICATION_ERROR(-20001, 'El formato del email no es vÃƒÂ¡lido');
    END IF;

    -- Valida que el telÃƒÂ©fono contenga solo nÃƒÂºmeros y guiones
    IF :NEW.telefono IS NOT NULL AND NOT REGEXP_LIKE(:NEW.telefono, '^[0-9-]+$') THEN
        RAISE_APPLICATION_ERROR(-20002, 'El telÃƒÂ©fono debe contener solo nÃƒÂºmeros y guiones');
    END IF;
END;
/

