create PACKAGE BODY PKG_VENTAS AS
    FUNCTION fn_listar_facturas RETURN SYS_REFCURSOR AS
        cur SYS_REFCURSOR;
    BEGIN
        OPEN cur FOR
            SELECT f.IdFactura, f.numero_factura, f.fecha, f.subtotal, f.impuesto, f.total,
                   f.estado, f.metodo_pago, f.observaciones,
                   c.nombreCliente || ' ' || c.apellidos AS cliente
            FROM Factura f
            JOIN Clientes c ON c.IdCliente = f.IdCliente
            ORDER BY f.fecha DESC, f.IdFactura DESC;
        RETURN cur;
    END;

    FUNCTION fn_obtener_factura(p_id NUMBER) RETURN SYS_REFCURSOR AS
        cur SYS_REFCURSOR;
    BEGIN
        OPEN cur FOR
            SELECT f.*, c.nombreCliente, c.apellidos, c.email
            FROM Factura f JOIN Clientes c ON c.IdCliente = f.IdCliente
            WHERE f.IdFactura = p_id;
        RETURN cur;
    END;

    PROCEDURE sp_insertar_factura(
        p_numero VARCHAR2,
        p_fecha DATE,
        p_id_cliente NUMBER,
        p_metodo_pago VARCHAR2,
        p_estado VARCHAR2,
        p_observaciones VARCHAR2,
        p_id_factura OUT NUMBER
    ) AS
    BEGIN
        INSERT INTO Factura (numero_factura, fecha, IdCliente, metodo_pago, estado, observaciones)
        VALUES (p_numero, NVL(p_fecha, SYSDATE), p_id_cliente, p_metodo_pago, p_estado, p_observaciones)
        RETURNING IdFactura INTO p_id_factura;
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE;
    END;

    PROCEDURE sp_agregar_detalle_factura(
        p_id_factura NUMBER,
        p_id_producto NUMBER,
        p_precio NUMBER,
        p_cantidad NUMBER,
        p_descuento NUMBER
    ) AS
    BEGIN
        INSERT INTO detalleFactura (IdFactura, IdProducto, precioUni, cantidad, descuento_item)
        VALUES (p_id_factura, p_id_producto, p_precio, p_cantidad, NVL(p_descuento, 0));
        -- trg_factura_actualizar_total actualizarÃƒÂ¡ subtotal/impuesto/total
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE;
    END;

    PROCEDURE sp_anular_factura(p_id NUMBER) AS
    BEGIN
        UPDATE Factura SET estado = 'ANULADA', fecha_modificacion = SYSDATE
        WHERE IdFactura = p_id;
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE;
    END;
END PKG_VENTAS;
/

