create PACKAGE BODY PKG_HORARIOS AS
    FUNCTION fn_listar_horarios RETURN SYS_REFCURSOR AS
        cur SYS_REFCURSOR;
    BEGIN
        OPEN cur FOR
            SELECT h.IdHorario, h.IdEmpleado, h.fecha, h.hora_entrada, h.hora_salida,
                   h.horas_trabajadas, h.observaciones,
                   e.nombreEmpleado, e.apellidos
            FROM Horarios h JOIN Empleados e ON e.IdEmpleado = h.IdEmpleado
            ORDER BY h.fecha DESC;
        RETURN cur;
    END;

    FUNCTION fn_obtener_horario(p_id NUMBER) RETURN SYS_REFCURSOR AS
        cur SYS_REFCURSOR;
    BEGIN
        OPEN cur FOR
            SELECT h.*, e.nombreEmpleado, e.apellidos
            FROM Horarios h JOIN Empleados e ON e.IdEmpleado = h.IdEmpleado
            WHERE h.IdHorario = p_id;
        RETURN cur;
    END;

    FUNCTION fn_listar_horarios_por_empleado(p_id_empleado NUMBER) RETURN SYS_REFCURSOR AS
        cur SYS_REFCURSOR;
    BEGIN
        OPEN cur FOR
            SELECT * FROM Horarios WHERE IdEmpleado = p_id_empleado ORDER BY fecha DESC;
        RETURN cur;
    END;

    PROCEDURE sp_insertar_horario(
        p_id_empleado NUMBER,
        p_fecha DATE,
        p_hora_entrada NUMBER,
        p_hora_salida NUMBER,
        p_observaciones VARCHAR2,
        p_id_horario OUT NUMBER
    ) AS
    BEGIN
        INSERT INTO Horarios (IdEmpleado, fecha, hora_entrada, hora_salida, observaciones)
        VALUES (p_id_empleado, p_fecha, p_hora_entrada, p_hora_salida, p_observaciones)
        RETURNING IdHorario INTO p_id_horario;
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE;
    END;

    PROCEDURE sp_actualizar_horario(
        p_id NUMBER,
        p_fecha DATE,
        p_hora_entrada NUMBER,
        p_hora_salida NUMBER,
        p_observaciones VARCHAR2
    ) AS
    BEGIN
        UPDATE Horarios
           SET fecha = p_fecha,
               hora_entrada = p_hora_entrada,
               hora_salida = p_hora_salida,
               observaciones = p_observaciones
         WHERE IdHorario = p_id;
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE;
    END;

    PROCEDURE sp_eliminar_horario(p_id NUMBER) AS
    BEGIN
        DELETE FROM Horarios WHERE IdHorario = p_id;
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE;
    END;
END PKG_HORARIOS;
/

