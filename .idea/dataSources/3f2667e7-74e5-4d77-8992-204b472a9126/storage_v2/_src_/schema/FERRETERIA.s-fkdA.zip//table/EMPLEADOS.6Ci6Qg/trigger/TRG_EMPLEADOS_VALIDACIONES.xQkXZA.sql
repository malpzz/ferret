create trigger TRG_EMPLEADOS_VALIDACIONES
    before insert or update
    on EMPLEADOS
    for each row
BEGIN
    -- Valida que el email tenga un formato correcto
    IF :NEW.email IS NOT NULL AND NOT REGEXP_LIKE(:NEW.email, '^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$') THEN
        RAISE_APPLICATION_ERROR(-20003, 'El formato del email del empleado no es vÃƒÂ¡lido');
    END IF;

    -- Valida que el salario sea positivo
    IF :NEW.salario IS NOT NULL AND :NEW.salario <= 0 THEN
        RAISE_APPLICATION_ERROR(-20004, 'El salario debe ser mayor a cero');
    END IF;
END;
/

