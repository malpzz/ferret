create trigger TRG_PEDIDOS_ACTUALIZAR_TOTAL
    instead of insert or update or delete
    on DETALLEPEDIDO
    for each row
    COMPOUND TRIGGER
  TYPE t_ids IS TABLE OF NUMBER INDEX BY PLS_INTEGER;
  g_ids t_ids;

  PROCEDURE add_id(p_id NUMBER) IS
BEGIN
    IF p_id IS NOT NULL THEN
      g_ids(g_ids.COUNT+1) := p_id;
    END IF;
  END;

  BEFORE STATEMENT IS BEGIN g_ids.DELETE; END BEFORE STATEMENT;

  AFTER EACH ROW IS
  BEGIN
    IF INSERTING OR UPDATING THEN
      add_id(:NEW.IdPedido);
    ELSIF DELETING THEN
      add_id(:OLD.IdPedido);
    END IF;
  END AFTER EACH ROW;

  AFTER STATEMENT IS
  BEGIN
    IF g_ids.COUNT > 0 THEN
      FOR i IN 1..g_ids.COUNT LOOP
        DECLARE v_total NUMBER(12,2);
        BEGIN
    SELECT NVL(SUM(precioUni * cantidad), 0)
    INTO v_total
    FROM detallePedido
           WHERE IdPedido = g_ids(i);
    UPDATE Pedidos
             SET total = v_total,
                 fecha_modificacion = SYSDATE
           WHERE IdPedido = g_ids(i);
        END;
      END LOOP;
    END IF;
  END AFTER STATEMENT;
END;
/

