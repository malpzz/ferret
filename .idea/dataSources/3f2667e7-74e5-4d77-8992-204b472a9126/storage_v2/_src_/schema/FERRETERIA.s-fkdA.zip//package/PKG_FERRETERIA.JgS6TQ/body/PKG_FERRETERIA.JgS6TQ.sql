create PACKAGE BODY PKG_FERRETERIA AS

    -- Procedimiento para insertar rol
    PROCEDURE sp_insertar_rol(p_nombre VARCHAR2, p_descripcion VARCHAR2, p_resultado OUT t_resultado) AS
    BEGIN
        -- Inserta nuevo rol en la tabla Roles
        INSERT INTO Roles (nombre, descripcion)
        VALUES (p_nombre, p_descripcion);

        -- Confirma la transacciÃƒÂ³n
        COMMIT;

        -- Retorna resultado exitoso
        p_resultado.exito := TRUE;
        p_resultado.mensaje := 'Rol insertado correctamente';

    EXCEPTION
        WHEN DUP_VAL_ON_INDEX THEN
            ROLLBACK;
            p_resultado.exito := FALSE;
            p_resultado.mensaje := 'Ya existe un rol con ese nombre';
        WHEN OTHERS THEN
            ROLLBACK;
            p_resultado.exito := FALSE;
            p_resultado.mensaje := 'Error al insertar rol: ' || SQLERRM;
    END sp_insertar_rol;

    -- Procedimiento para actualizar rol
    PROCEDURE sp_actualizar_rol(p_id NUMBER, p_nombre VARCHAR2, p_descripcion VARCHAR2, p_resultado OUT t_resultado) AS
        v_count NUMBER;
    BEGIN
        -- Verifica que el rol existe
        SELECT COUNT(*) INTO v_count FROM Roles WHERE IdRol = p_id;
        IF v_count = 0 THEN
            p_resultado.exito := FALSE;
            p_resultado.mensaje := 'El rol no existe';
            RETURN;
        END IF;

        -- Actualiza el rol
        UPDATE Roles
        SET nombre = p_nombre,
            descripcion = p_descripcion,
            fecha_modificacion = SYSDATE
        WHERE IdRol = p_id;

        COMMIT;
        p_resultado.exito := TRUE;
        p_resultado.mensaje := 'Rol actualizado correctamente';

    EXCEPTION
        WHEN DUP_VAL_ON_INDEX THEN
            ROLLBACK;
            p_resultado.exito := FALSE;
            p_resultado.mensaje := 'Ya existe un rol con ese nombre';
        WHEN OTHERS THEN
            ROLLBACK;
            p_resultado.exito := FALSE;
            p_resultado.mensaje := 'Error al actualizar rol: ' || SQLERRM;
    END sp_actualizar_rol;

    -- Procedimiento para eliminar rol
    PROCEDURE sp_eliminar_rol(p_id NUMBER, p_resultado OUT t_resultado) AS
        v_count NUMBER;
    BEGIN
        -- Verifica si hay usuarios asociados al rol
        SELECT COUNT(*) INTO v_count FROM Usuarios WHERE IdRol = p_id;
        IF v_count > 0 THEN
            p_resultado.exito := FALSE;
            p_resultado.mensaje := 'No se puede eliminar el rol porque tiene usuarios asociados';
            RETURN;
        END IF;

        -- Elimina el rol
        DELETE FROM Roles WHERE IdRol = p_id;

        IF SQL%ROWCOUNT = 0 THEN
            p_resultado.exito := FALSE;
            p_resultado.mensaje := 'El rol no existe';
        ELSE
            COMMIT;
            p_resultado.exito := TRUE;
            p_resultado.mensaje := 'Rol eliminado correctamente';
        END IF;

    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            p_resultado.exito := FALSE;
            p_resultado.mensaje := 'Error al eliminar rol: ' || SQLERRM;
    END sp_eliminar_rol;

    -- FunciÃƒÂ³n para obtener un rol especÃƒÂ­fico
    FUNCTION fn_obtener_rol(p_id NUMBER) RETURN SYS_REFCURSOR AS
        cur_rol SYS_REFCURSOR;
    BEGIN
        OPEN cur_rol FOR
            SELECT IdRol, nombre, descripcion, activo, fecha_creacion, fecha_modificacion
            FROM Roles
            WHERE IdRol = p_id;
        RETURN cur_rol;
    END fn_obtener_rol;

    -- FunciÃƒÂ³n para listar todos los roles
    FUNCTION fn_listar_roles RETURN SYS_REFCURSOR AS
        cur_roles SYS_REFCURSOR;
    BEGIN
        OPEN cur_roles FOR
            SELECT IdRol, nombre, descripcion, activo, fecha_creacion, fecha_modificacion
            FROM Roles
            ORDER BY nombre;
        RETURN cur_roles;
    END fn_listar_roles;

    -- PROCEDIMIENTO CON CURSOR: Insertar usuario
    PROCEDURE sp_insertar_usuario(p_nombre_usuario VARCHAR2, p_contrasena VARCHAR2, p_email VARCHAR2,
                                 p_nombre VARCHAR2, p_apellidos VARCHAR2, p_telefono VARCHAR2,
                                 p_id_rol NUMBER, p_resultado OUT t_resultado) AS
        -- Cursor para validar que el rol existe y estÃƒÂ¡ activo
        CURSOR cur_validar_rol IS
            SELECT activo FROM Roles WHERE IdRol = p_id_rol;

        v_rol_activo NUMBER;
    BEGIN
        -- Valida que el rol existe y estÃƒÂ¡ activo usando cursor
        OPEN cur_validar_rol;
        FETCH cur_validar_rol INTO v_rol_activo;

        IF cur_validar_rol%NOTFOUND THEN
            CLOSE cur_validar_rol;
            p_resultado.exito := FALSE;
            p_resultado.mensaje := 'El rol especificado no existe';
            RETURN;
        END IF;

        IF v_rol_activo = 0 THEN
            CLOSE cur_validar_rol;
            p_resultado.exito := FALSE;
            p_resultado.mensaje := 'El rol especificado estÃƒÂ¡ inactivo';
            RETURN;
        END IF;

        CLOSE cur_validar_rol;

        -- Inserta el nuevo usuario
        INSERT INTO Usuarios (nombreUsuario, contrasena, email, nombre, apellidos, telefono, IdRol)
        VALUES (p_nombre_usuario, p_contrasena, p_email, p_nombre, p_apellidos, p_telefono, p_id_rol);

        COMMIT;
        p_resultado.exito := TRUE;
        p_resultado.mensaje := 'Usuario insertado correctamente';

    EXCEPTION
        WHEN DUP_VAL_ON_INDEX THEN
            ROLLBACK;
            p_resultado.exito := FALSE;
            p_resultado.mensaje := 'Ya existe un usuario con ese nombre de usuario o email';
        WHEN OTHERS THEN
            ROLLBACK;
            p_resultado.exito := FALSE;
            p_resultado.mensaje := 'Error al insertar usuario: ' || SQLERRM;
    END sp_insertar_usuario;

    -- PROCEDIMIENTO CON CURSOR: Actualizar usuario
    PROCEDURE sp_actualizar_usuario(p_id NUMBER, p_nombre_usuario VARCHAR2, p_contrasena VARCHAR2,
                                   p_email VARCHAR2, p_nombre VARCHAR2, p_apellidos VARCHAR2,
                                   p_telefono VARCHAR2, p_id_rol NUMBER, p_resultado OUT t_resultado) AS
        -- Cursor para validar que el usuario existe
        CURSOR cur_validar_usuario IS
            SELECT activo FROM Usuarios WHERE IdUsuario = p_id;

        -- Cursor para validar que el rol existe y estÃƒÂ¡ activo
        CURSOR cur_validar_rol IS
            SELECT activo FROM Roles WHERE IdRol = p_id_rol;

        v_usuario_existe NUMBER;
        v_rol_activo NUMBER;
    BEGIN
        -- Valida que el usuario existe
        OPEN cur_validar_usuario;
        FETCH cur_validar_usuario INTO v_usuario_existe;

        IF cur_validar_usuario%NOTFOUND THEN
            CLOSE cur_validar_usuario;
            p_resultado.exito := FALSE;
            p_resultado.mensaje := 'El usuario no existe';
            RETURN;
        END IF;
        CLOSE cur_validar_usuario;

        -- Valida que el rol existe y estÃƒÂ¡ activo
        OPEN cur_validar_rol;
        FETCH cur_validar_rol INTO v_rol_activo;

        IF cur_validar_rol%NOTFOUND OR v_rol_activo = 0 THEN
            CLOSE cur_validar_rol;
            p_resultado.exito := FALSE;
            p_resultado.mensaje := 'El rol especificado no existe o estÃƒÂ¡ inactivo';
            RETURN;
        END IF;
        CLOSE cur_validar_rol;

        -- Actualiza el usuario
        UPDATE Usuarios
        SET nombreUsuario = p_nombre_usuario,
            contrasena = p_contrasena,
            email = p_email,
            nombre = p_nombre,
            apellidos = p_apellidos,
            telefono = p_telefono,
            IdRol = p_id_rol,
            fecha_modificacion = SYSDATE
        WHERE IdUsuario = p_id;

        COMMIT;
        p_resultado.exito := TRUE;
        p_resultado.mensaje := 'Usuario actualizado correctamente';

    EXCEPTION
        WHEN DUP_VAL_ON_INDEX THEN
            ROLLBACK;
            p_resultado.exito := FALSE;
            p_resultado.mensaje := 'Ya existe un usuario con ese nombre de usuario o email';
        WHEN OTHERS THEN
            ROLLBACK;
            p_resultado.exito := FALSE;
            p_resultado.mensaje := 'Error al actualizar usuario: ' || SQLERRM;
    END sp_actualizar_usuario;

    -- Procedimiento para eliminar usuario
    PROCEDURE sp_eliminar_usuario(p_id NUMBER, p_resultado OUT t_resultado) AS
        v_count NUMBER;
    BEGIN
        -- Verifica si hay facturas o pedidos asociados al usuario
        SELECT COUNT(*) INTO v_count
        FROM (SELECT IdUsuario FROM Factura WHERE IdUsuario = p_id
              UNION ALL
              SELECT IdUsuario FROM Pedidos WHERE IdUsuario = p_id);

        IF v_count > 0 THEN
            p_resultado.exito := FALSE;
            p_resultado.mensaje := 'No se puede eliminar el usuario porque tiene registros asociados';
            RETURN;
        END IF;

        -- Elimina el usuario
        DELETE FROM Usuarios WHERE IdUsuario = p_id;

        IF SQL%ROWCOUNT = 0 THEN
            p_resultado.exito := FALSE;
            p_resultado.mensaje := 'El usuario no existe';
        ELSE
            COMMIT;
            p_resultado.exito := TRUE;
            p_resultado.mensaje := 'Usuario eliminado correctamente';
        END IF;

    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            p_resultado.exito := FALSE;
            p_resultado.mensaje := 'Error al eliminar usuario: ' || SQLERRM;
    END sp_eliminar_usuario;

    -- PROCEDIMIENTO CON CURSOR: Validar usuarios activos
    PROCEDURE sp_validar_usuarios_activos AS
        -- Cursor para obtener usuarios que no han accedido en los ÃƒÂºltimos 90 dÃƒÂ­as
        CURSOR cur_usuarios_inactivos IS
            SELECT IdUsuario, nombreUsuario, nombre, apellidos, ultimo_acceso
            FROM Usuarios
            WHERE activo = 1
            AND (ultimo_acceso IS NULL OR ultimo_acceso < SYSDATE - 90);

        v_count NUMBER := 0;
    BEGIN
        -- Recorre los usuarios inactivos y los marca como inactivos
        FOR usuario IN cur_usuarios_inactivos LOOP
            UPDATE Usuarios
            SET activo = 0,
                fecha_modificacion = SYSDATE
            WHERE IdUsuario = usuario.IdUsuario;

            v_count := v_count + 1;

            -- Log de la acciÃƒÂ³n (aquÃƒÂ­ podrÃƒÂ­as insertar en una tabla de auditorÃƒÂ­a)
            DBMS_OUTPUT.PUT_LINE('Usuario ' || usuario.nombreUsuario || ' marcado como inactivo');
        END LOOP;

        COMMIT;
        DBMS_OUTPUT.PUT_LINE('Total de usuarios marcados como inactivos: ' || v_count);

    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            DBMS_OUTPUT.PUT_LINE('Error al validar usuarios activos: ' || SQLERRM);
    END sp_validar_usuarios_activos;

    -- FunciÃƒÂ³n para obtener un usuario especÃƒÂ­fico
    FUNCTION fn_obtener_usuario(p_id NUMBER) RETURN SYS_REFCURSOR AS
        cur_usuario SYS_REFCURSOR;
    BEGIN
        OPEN cur_usuario FOR
            SELECT u.IdUsuario, u.nombreUsuario, u.email, u.nombre, u.apellidos,
                   u.telefono, u.activo, u.ultimo_acceso, u.fecha_creacion,
                   r.nombre as nombre_rol
            FROM Usuarios u
            INNER JOIN Roles r ON u.IdRol = r.IdRol
            WHERE u.IdUsuario = p_id;
        RETURN cur_usuario;
    END fn_obtener_usuario;

    -- FunciÃƒÂ³n para listar todos los usuarios
    FUNCTION fn_listar_usuarios RETURN SYS_REFCURSOR AS
        cur_usuarios SYS_REFCURSOR;
    BEGIN
        OPEN cur_usuarios FOR
            SELECT u.IdUsuario, u.nombreUsuario, u.email, u.nombre, u.apellidos,
                   u.telefono, u.activo, u.ultimo_acceso, u.fecha_creacion,
                   r.nombre as nombre_rol
            FROM Usuarios u
            INNER JOIN Roles r ON u.IdRol = r.IdRol
            ORDER BY u.nombre, u.apellidos;
        RETURN cur_usuarios;
    END fn_listar_usuarios;

    -- PROCEDIMIENTO CON CURSOR: Insertar cliente
    PROCEDURE sp_insertar_cliente(p_nombre VARCHAR2, p_apellidos VARCHAR2, p_direccion VARCHAR2,
                                 p_telefono VARCHAR2, p_email VARCHAR2, p_cedula VARCHAR2,
                                 p_tipo_cliente VARCHAR2, p_resultado OUT t_resultado) AS
        -- Cursor para verificar clientes duplicados
        CURSOR cur_verificar_duplicado IS
            SELECT COUNT(*) as total
            FROM Clientes
            WHERE UPPER(nombreCliente) = UPPER(p_nombre)
            AND UPPER(apellidos) = UPPER(p_apellidos)
            AND cedula = p_cedula;

        v_duplicado NUMBER;
    BEGIN
        -- Verifica duplicados usando cursor
        OPEN cur_verificar_duplicado;
        FETCH cur_verificar_duplicado INTO v_duplicado;
        CLOSE cur_verificar_duplicado;

        IF v_duplicado > 0 THEN
            p_resultado.exito := FALSE;
            p_resultado.mensaje := 'Ya existe un cliente con los mismos datos';
            RETURN;
        END IF;

        -- Inserta el nuevo cliente
        INSERT INTO Clientes (nombreCliente, apellidos, direccion, telefono, email, cedula, tipo_cliente)
        VALUES (p_nombre, p_apellidos, p_direccion, p_telefono, p_email, p_cedula, p_tipo_cliente);

        COMMIT;
        p_resultado.exito := TRUE;
        p_resultado.mensaje := 'Cliente insertado correctamente';

    EXCEPTION
        WHEN DUP_VAL_ON_INDEX THEN
            ROLLBACK;
            p_resultado.exito := FALSE;
            p_resultado.mensaje := 'Ya existe un cliente con ese email o cÃƒÂ©dula';
        WHEN OTHERS THEN
            ROLLBACK;
            p_resultado.exito := FALSE;
            p_resultado.mensaje := 'Error al insertar cliente: ' || SQLERRM;
    END sp_insertar_cliente;

    -- Procedimiento para actualizar cliente
    PROCEDURE sp_actualizar_cliente(p_id NUMBER, p_nombre VARCHAR2, p_apellidos VARCHAR2,
                                   p_direccion VARCHAR2, p_telefono VARCHAR2, p_email VARCHAR2,
                                   p_cedula VARCHAR2, p_tipo_cliente VARCHAR2, p_resultado OUT t_resultado) AS
        v_count NUMBER;
    BEGIN
        -- Verifica que el cliente existe
        SELECT COUNT(*) INTO v_count FROM Clientes WHERE IdCliente = p_id;
        IF v_count = 0 THEN
            p_resultado.exito := FALSE;
            p_resultado.mensaje := 'El cliente no existe';
            RETURN;
        END IF;

        -- Actualiza el cliente
        UPDATE Clientes
        SET nombreCliente = p_nombre,
            apellidos = p_apellidos,
            direccion = p_direccion,
            telefono = p_telefono,
            email = p_email,
            cedula = p_cedula,
            tipo_cliente = p_tipo_cliente,
            fecha_modificacion = SYSDATE
        WHERE IdCliente = p_id;

        COMMIT;
        p_resultado.exito := TRUE;
        p_resultado.mensaje := 'Cliente actualizado correctamente';

    EXCEPTION
        WHEN DUP_VAL_ON_INDEX THEN
            ROLLBACK;
            p_resultado.exito := FALSE;
            p_resultado.mensaje := 'Ya existe un cliente con ese email o cÃƒÂ©dula';
        WHEN OTHERS THEN
            ROLLBACK;
            p_resultado.exito := FALSE;
            p_resultado.mensaje := 'Error al actualizar cliente: ' || SQLERRM;
    END sp_actualizar_cliente;

    -- Procedimiento para eliminar cliente
    PROCEDURE sp_eliminar_cliente(p_id NUMBER, p_resultado OUT t_resultado) AS
        v_count NUMBER;
    BEGIN
        -- Verifica si hay facturas asociadas al cliente
        SELECT COUNT(*) INTO v_count FROM Factura WHERE IdCliente = p_id;

        IF v_count > 0 THEN
            p_resultado.exito := FALSE;
            p_resultado.mensaje := 'No se puede eliminar el cliente porque tiene facturas asociadas';
            RETURN;
        END IF;

        -- Elimina el cliente
        DELETE FROM Clientes WHERE IdCliente = p_id;

        IF SQL%ROWCOUNT = 0 THEN
            p_resultado.exito := FALSE;
            p_resultado.mensaje := 'El cliente no existe';
        ELSE
            COMMIT;
            p_resultado.exito := TRUE;
            p_resultado.mensaje := 'Cliente eliminado correctamente';
        END IF;

    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            p_resultado.exito := FALSE;
            p_resultado.mensaje := 'Error al eliminar cliente: ' || SQLERRM;
    END sp_eliminar_cliente;

    -- Wrappers JDBC para Clientes
    PROCEDURE sp_insertar_cliente_jdbc(p_nombre VARCHAR2, p_apellidos VARCHAR2, p_direccion VARCHAR2,
                                      p_telefono VARCHAR2, p_email VARCHAR2, p_cedula VARCHAR2,
                                      p_tipo_cliente VARCHAR2) AS
        v_res t_resultado;
    BEGIN
        sp_insertar_cliente(p_nombre, p_apellidos, p_direccion, p_telefono, p_email, p_cedula, p_tipo_cliente, v_res);
        IF NOT v_res.exito THEN
            RAISE_APPLICATION_ERROR(-20010, v_res.mensaje);
        END IF;
    END sp_insertar_cliente_jdbc;

    PROCEDURE sp_actualizar_cliente_jdbc(p_id NUMBER, p_nombre VARCHAR2, p_apellidos VARCHAR2,
                                         p_direccion VARCHAR2, p_telefono VARCHAR2, p_email VARCHAR2,
                                         p_cedula VARCHAR2, p_tipo_cliente VARCHAR2) AS
        v_res t_resultado;
    BEGIN
        sp_actualizar_cliente(p_id, p_nombre, p_apellidos, p_direccion, p_telefono, p_email, p_cedula, p_tipo_cliente, v_res);
        IF NOT v_res.exito THEN
            RAISE_APPLICATION_ERROR(-20011, v_res.mensaje);
        END IF;
    END sp_actualizar_cliente_jdbc;

    PROCEDURE sp_eliminar_cliente_jdbc(p_id NUMBER) AS
        v_res t_resultado;
    BEGIN
        sp_eliminar_cliente(p_id, v_res);
        IF NOT v_res.exito THEN
            RAISE_APPLICATION_ERROR(-20012, v_res.mensaje);
        END IF;
    END sp_eliminar_cliente_jdbc;

    -- PROCEDIMIENTO CON CURSOR: Actualizar lÃƒÂ­mites de crÃƒÂ©dito de clientes
    PROCEDURE sp_actualizar_limites_credito AS
        -- Cursor para clientes VIP con historial de compras
        CURSOR cur_clientes_vip IS
            SELECT c.IdCliente, c.nombreCliente, c.apellidos,
                   NVL(SUM(f.total), 0) as total_compras,
                   COUNT(f.IdFactura) as num_facturas
            FROM Clientes c
            LEFT JOIN Factura f ON c.IdCliente = f.IdCliente
                AND f.fecha >= ADD_MONTHS(SYSDATE, -12)
                AND f.estado = 'PAGADA'
            WHERE c.tipo_cliente = 'VIP' AND c.activo = 1
            GROUP BY c.IdCliente, c.nombreCliente, c.apellidos
            HAVING NVL(SUM(f.total), 0) > 10000;

        v_nuevo_limite NUMBER;
        v_count NUMBER := 0;
    BEGIN
        -- Recorre clientes VIP y actualiza sus lÃƒÂ­mites de crÃƒÂ©dito
        FOR cliente IN cur_clientes_vip LOOP
            -- Calcula nuevo lÃƒÂ­mite basado en el historial (20% del total de compras)
            v_nuevo_limite := ROUND(cliente.total_compras * 0.20, 2);

            -- MÃƒÂ­nimo de $5000 para clientes VIP
            IF v_nuevo_limite < 5000 THEN
                v_nuevo_limite := 5000;
            END IF;

            -- Actualiza el lÃƒÂ­mite de crÃƒÂ©dito
            UPDATE Clientes
            SET limite_credito = v_nuevo_limite,
                fecha_modificacion = SYSDATE
            WHERE IdCliente = cliente.IdCliente;

            v_count := v_count + 1;

            DBMS_OUTPUT.PUT_LINE('Cliente ' || cliente.nombreCliente || ' ' || cliente.apellidos ||
                               ' - Nuevo lÃƒÂ­mite: $' || v_nuevo_limite);
        END LOOP;

        COMMIT;
        DBMS_OUTPUT.PUT_LINE('Total de lÃƒÂ­mites de crÃƒÂ©dito actualizados: ' || v_count);

    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            DBMS_OUTPUT.PUT_LINE('Error al actualizar lÃƒÂ­mites de crÃƒÂ©dito: ' || SQLERRM);
    END sp_actualizar_limites_credito;

    -- FunciÃƒÂ³n para obtener un cliente especÃƒÂ­fico
    FUNCTION fn_obtener_cliente(p_id NUMBER) RETURN SYS_REFCURSOR AS
        cur_cliente SYS_REFCURSOR;
    BEGIN
        OPEN cur_cliente FOR
            SELECT IdCliente, nombreCliente, apellidos, direccion, telefono,
                   email, cedula, tipo_cliente, limite_credito, activo,
                   fecha_registro, fecha_modificacion
            FROM Clientes
            WHERE IdCliente = p_id;
        RETURN cur_cliente;
    END fn_obtener_cliente;

    -- FunciÃƒÂ³n para listar todos los clientes
    FUNCTION fn_listar_clientes RETURN SYS_REFCURSOR AS
        cur_clientes SYS_REFCURSOR;
    BEGIN
        OPEN cur_clientes FOR
            SELECT IdCliente, nombreCliente, apellidos, direccion, telefono,
                   email, cedula, tipo_cliente, limite_credito, activo,
                   fecha_registro, fecha_modificacion
            FROM Clientes
            ORDER BY nombreCliente, apellidos;
        RETURN cur_clientes;
    END fn_listar_clientes;

    -- Los demÃƒÂ¡s procedimientos CRUD para Empleados, Proveedores, Productos siguen el mismo patrÃƒÂ³n...
    -- (Por brevedad, incluyo solo algunos representativos)

    -- PROCEDIMIENTO CON CURSOR: Insertar producto
    PROCEDURE sp_insertar_producto(p_nombre VARCHAR2, p_descripcion VARCHAR2, p_codigo VARCHAR2,
                                  p_categoria VARCHAR2, p_marca VARCHAR2, p_precio NUMBER,
                                  p_precio_compra NUMBER, p_unidad_medida VARCHAR2,
                                  p_stock_minimo NUMBER, p_id_proveedor NUMBER, p_resultado OUT t_resultado) AS
        -- Cursor para validar proveedor
        CURSOR cur_validar_proveedor IS
            SELECT activo FROM Proveedores WHERE IdProveedor = p_id_proveedor;

        v_proveedor_activo NUMBER;
        v_id_producto NUMBER;
    BEGIN
        -- Valida que el proveedor existe y estÃƒÂ¡ activo
        OPEN cur_validar_proveedor;
        FETCH cur_validar_proveedor INTO v_proveedor_activo;

        IF cur_validar_proveedor%NOTFOUND THEN
            CLOSE cur_validar_proveedor;
            p_resultado.exito := FALSE;
            p_resultado.mensaje := 'El proveedor especificado no existe';
            RETURN;
        END IF;

        IF v_proveedor_activo = 0 THEN
            CLOSE cur_validar_proveedor;
            p_resultado.exito := FALSE;
            p_resultado.mensaje := 'El proveedor especificado estÃƒÂ¡ inactivo';
            RETURN;
        END IF;

        CLOSE cur_validar_proveedor;

        -- Inserta el nuevo producto y obtiene su Id
        INSERT INTO Productos (nombreProducto, descripcion, codigo_producto, categoria, marca,
                              precio, precio_compra, unidad_medida, stock_minimo, IdProveedor)
        VALUES (p_nombre, p_descripcion, p_codigo, p_categoria, p_marca,
                p_precio, p_precio_compra, p_unidad_medida, p_stock_minimo, p_id_proveedor)
        RETURNING IdProducto INTO v_id_producto;

        -- Crea registro inicial de stock
        INSERT INTO Stock (cantidad, IdProducto)
        VALUES (0, v_id_producto);

        COMMIT;
        p_resultado.exito := TRUE;
        p_resultado.mensaje := 'Producto insertado correctamente';

    EXCEPTION
        WHEN DUP_VAL_ON_INDEX THEN
            ROLLBACK;
            p_resultado.exito := FALSE;
            p_resultado.mensaje := 'Ya existe un producto con ese cÃƒÂ³digo';
        WHEN OTHERS THEN
            ROLLBACK;
            p_resultado.exito := FALSE;
            p_resultado.mensaje := 'Error al insertar producto: ' || SQLERRM;
    END sp_insertar_producto;

    -- PROCEDIMIENTO: Actualizar producto
    PROCEDURE sp_actualizar_producto(p_id NUMBER, p_nombre VARCHAR2, p_descripcion VARCHAR2,
                                     p_codigo VARCHAR2, p_categoria VARCHAR2, p_marca VARCHAR2,
                                     p_precio NUMBER, p_precio_compra NUMBER, p_unidad_medida VARCHAR2,
                                     p_stock_minimo NUMBER, p_id_proveedor NUMBER, p_resultado OUT t_resultado) AS
        v_count NUMBER;
        v_prov_activo NUMBER;
        CURSOR cur_validar_prov IS
            SELECT activo FROM Proveedores WHERE IdProveedor = p_id_proveedor;
    BEGIN
        -- Verifica que el producto existe
        SELECT COUNT(*) INTO v_count FROM Productos WHERE IdProducto = p_id;
        IF v_count = 0 THEN
            p_resultado.exito := FALSE;
            p_resultado.mensaje := 'El producto no existe';
            RETURN;
        END IF;

        -- Verifica proveedor
        OPEN cur_validar_prov;
        FETCH cur_validar_prov INTO v_prov_activo;
        IF cur_validar_prov%NOTFOUND THEN
            CLOSE cur_validar_prov;
            p_resultado.exito := FALSE;
            p_resultado.mensaje := 'El proveedor especificado no existe';
            RETURN;
        END IF;
        CLOSE cur_validar_prov;

        IF v_prov_activo = 0 THEN
            p_resultado.exito := FALSE;
            p_resultado.mensaje := 'El proveedor especificado estÃ¡ inactivo';
            RETURN;
        END IF;

        -- Actualiza el producto
        UPDATE Productos
           SET nombreProducto = p_nombre,
               descripcion = p_descripcion,
               codigo_producto = p_codigo,
               categoria = p_categoria,
               marca = p_marca,
               precio = p_precio,
               precio_compra = p_precio_compra,
               unidad_medida = p_unidad_medida,
               stock_minimo = p_stock_minimo,
               IdProveedor = p_id_proveedor,
               fecha_modificacion = SYSDATE
         WHERE IdProducto = p_id;

        COMMIT;
        p_resultado.exito := TRUE;
        p_resultado.mensaje := 'Producto actualizado correctamente';

    EXCEPTION
        WHEN DUP_VAL_ON_INDEX THEN
            ROLLBACK;
            p_resultado.exito := FALSE;
            p_resultado.mensaje := 'Ya existe un producto con ese cÃ³digo';
        WHEN OTHERS THEN
            ROLLBACK;
            p_resultado.exito := FALSE;
            p_resultado.mensaje := 'Error al actualizar producto: ' || SQLERRM;
    END sp_actualizar_producto;

    -- PROCEDIMIENTO: Eliminar producto
    PROCEDURE sp_eliminar_producto(p_id NUMBER, p_resultado OUT t_resultado) AS
        v_count NUMBER;
    BEGIN
        -- Verifica si el producto estÃ¡ referenciado en detalleFactura o detallePedido
        SELECT COUNT(*) INTO v_count FROM detalleFactura WHERE IdProducto = p_id;
        IF v_count > 0 THEN
            p_resultado.exito := FALSE;
            p_resultado.mensaje := 'No se puede eliminar el producto porque tiene facturas asociadas';
            RETURN;
        END IF;

        SELECT COUNT(*) INTO v_count FROM detallePedido WHERE IdProducto = p_id;
        IF v_count > 0 THEN
            p_resultado.exito := FALSE;
            p_resultado.mensaje := 'No se puede eliminar el producto porque tiene pedidos asociados';
            RETURN;
        END IF;

        -- Elimina primero el stock (si existe) y luego el producto
        DELETE FROM Stock WHERE IdProducto = p_id;
        DELETE FROM Productos WHERE IdProducto = p_id;

        IF SQL%ROWCOUNT = 0 THEN
            p_resultado.exito := FALSE;
            p_resultado.mensaje := 'El producto no existe';
        ELSE
            COMMIT;
            p_resultado.exito := TRUE;
            p_resultado.mensaje := 'Producto eliminado correctamente';
        END IF;

    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            p_resultado.exito := FALSE;
            p_resultado.mensaje := 'Error al eliminar producto: ' || SQLERRM;
    END sp_eliminar_producto;

    -- FUNCIONES: Obtener/Listar productos
    FUNCTION fn_obtener_producto(p_id NUMBER) RETURN SYS_REFCURSOR AS
        cur_producto SYS_REFCURSOR;
    BEGIN
        OPEN cur_producto FOR
            SELECT p.IdProducto, p.nombreProducto, p.descripcion, p.codigo_producto,
                   p.categoria, p.marca, p.precio, p.precio_compra, p.unidad_medida,
                   p.stock_minimo, p.activo, p.IdProveedor,
                   NVL(s.cantidad, 0) AS cantidadStock,
                   p.fecha_creacion, p.fecha_modificacion,
                   pr.nombreProveedor
              FROM Productos p
              LEFT JOIN Stock s ON s.IdProducto = p.IdProducto
              LEFT JOIN Proveedores pr ON pr.IdProveedor = p.IdProveedor
             WHERE p.IdProducto = p_id;
        RETURN cur_producto;
    END fn_obtener_producto;

    FUNCTION fn_listar_productos RETURN SYS_REFCURSOR AS
        cur_productos SYS_REFCURSOR;
    BEGIN
        OPEN cur_productos FOR
            SELECT p.IdProducto, p.nombreProducto, p.descripcion, p.codigo_producto,
                   p.categoria, p.marca, p.precio, p.precio_compra, p.unidad_medida,
                   p.stock_minimo, p.activo, p.IdProveedor,
                   NVL(s.cantidad, 0) AS cantidadStock,
                   p.fecha_creacion, p.fecha_modificacion,
                   prov.nombreProveedor
              FROM Productos p
              LEFT JOIN Stock s ON s.IdProducto = p.IdProducto
              LEFT JOIN Proveedores prov ON prov.IdProveedor = p.IdProveedor
             ORDER BY p.nombreProducto;
        RETURN cur_productos;
    END fn_listar_productos;

    -- Wrappers JDBC para Productos
    PROCEDURE sp_insertar_producto_jdbc(p_nombre VARCHAR2, p_descripcion VARCHAR2, p_codigo VARCHAR2,
                                        p_categoria VARCHAR2, p_marca VARCHAR2, p_precio NUMBER,
                                        p_precio_compra NUMBER, p_unidad_medida VARCHAR2,
                                        p_stock_minimo NUMBER, p_id_proveedor NUMBER) AS
        v_res t_resultado;
    BEGIN
        sp_insertar_producto(p_nombre, p_descripcion, p_codigo, p_categoria, p_marca, p_precio,
                              p_precio_compra, p_unidad_medida, p_stock_minimo, p_id_proveedor, v_res);
        IF NOT v_res.exito THEN
            RAISE_APPLICATION_ERROR(-20020, v_res.mensaje);
        END IF;
    END sp_insertar_producto_jdbc;

    PROCEDURE sp_actualizar_producto_jdbc(p_id NUMBER, p_nombre VARCHAR2, p_descripcion VARCHAR2,
                                          p_codigo VARCHAR2, p_categoria VARCHAR2, p_marca VARCHAR2,
                                          p_precio NUMBER, p_precio_compra NUMBER, p_unidad_medida VARCHAR2,
                                          p_stock_minimo NUMBER, p_id_proveedor NUMBER) AS
        v_res t_resultado;
    BEGIN
        sp_actualizar_producto(p_id, p_nombre, p_descripcion, p_codigo, p_categoria, p_marca,
                                p_precio, p_precio_compra, p_unidad_medida, p_stock_minimo, p_id_proveedor, v_res);
        IF NOT v_res.exito THEN
            RAISE_APPLICATION_ERROR(-20021, v_res.mensaje);
        END IF;
    END sp_actualizar_producto_jdbc;

    PROCEDURE sp_eliminar_producto_jdbc(p_id NUMBER) AS
        v_res t_resultado;
    BEGIN
        sp_eliminar_producto(p_id, v_res);
        IF NOT v_res.exito THEN
            RAISE_APPLICATION_ERROR(-20022, v_res.mensaje);
        END IF;
    END sp_eliminar_producto_jdbc;

    -- Wrappers JDBC para Empleados
    PROCEDURE sp_insertar_empleado_jdbc(p_nombre VARCHAR2, p_apellidos VARCHAR2, p_direccion VARCHAR2,
                                        p_telefono VARCHAR2, p_email VARCHAR2, p_cedula VARCHAR2,
                                        p_puesto VARCHAR2, p_salario NUMBER) AS
        v_res t_resultado;
    BEGIN
        sp_insertar_empleado(p_nombre, p_apellidos, p_direccion, p_telefono, p_email, p_cedula, p_puesto, p_salario, v_res);
        IF NOT v_res.exito THEN
            RAISE_APPLICATION_ERROR(-20030, v_res.mensaje);
        END IF;
    END sp_insertar_empleado_jdbc;

    PROCEDURE sp_actualizar_empleado_jdbc(p_id NUMBER, p_nombre VARCHAR2, p_apellidos VARCHAR2,
                                          p_direccion VARCHAR2, p_telefono VARCHAR2, p_email VARCHAR2,
                                          p_cedula VARCHAR2, p_puesto VARCHAR2, p_salario NUMBER) AS
        v_res t_resultado;
    BEGIN
        sp_actualizar_empleado(p_id, p_nombre, p_apellidos, p_direccion, p_telefono, p_email, p_cedula, p_puesto, p_salario, v_res);
        IF NOT v_res.exito THEN
            RAISE_APPLICATION_ERROR(-20031, v_res.mensaje);
        END IF;
    END sp_actualizar_empleado_jdbc;

    PROCEDURE sp_eliminar_empleado_jdbc(p_id NUMBER) AS
        v_res t_resultado;
    BEGIN
        sp_eliminar_empleado(p_id, v_res);
        IF NOT v_res.exito THEN
            RAISE_APPLICATION_ERROR(-20032, v_res.mensaje);
        END IF;
    END sp_eliminar_empleado_jdbc;

    -- Wrappers JDBC para Proveedores
    PROCEDURE sp_insertar_proveedor_jdbc(p_nombre VARCHAR2, p_direccion VARCHAR2, p_telefono VARCHAR2,
                                         p_email VARCHAR2, p_contacto VARCHAR2, p_ruc VARCHAR2,
                                         p_condiciones_pago VARCHAR2) AS
        v_res t_resultado;
    BEGIN
        sp_insertar_proveedor(p_nombre, p_direccion, p_telefono, p_email, p_contacto, p_ruc, p_condiciones_pago, v_res);
        IF NOT v_res.exito THEN
            RAISE_APPLICATION_ERROR(-20040, v_res.mensaje);
        END IF;
    END sp_insertar_proveedor_jdbc;

    PROCEDURE sp_actualizar_proveedor_jdbc(p_id NUMBER, p_nombre VARCHAR2, p_direccion VARCHAR2,
                                           p_telefono VARCHAR2, p_email VARCHAR2, p_contacto VARCHAR2,
                                           p_ruc VARCHAR2, p_condiciones_pago VARCHAR2) AS
        v_res t_resultado;
    BEGIN
        sp_actualizar_proveedor(p_id, p_nombre, p_direccion, p_telefono, p_email, p_contacto, p_ruc, p_condiciones_pago, v_res);
        IF NOT v_res.exito THEN
            RAISE_APPLICATION_ERROR(-20041, v_res.mensaje);
        END IF;
    END sp_actualizar_proveedor_jdbc;

    PROCEDURE sp_eliminar_proveedor_jdbc(p_id NUMBER) AS
        v_res t_resultado;
    BEGIN
        sp_eliminar_proveedor(p_id, v_res);
        IF NOT v_res.exito THEN
            RAISE_APPLICATION_ERROR(-20042, v_res.mensaje);
        END IF;
    END sp_eliminar_proveedor_jdbc;

    -- PROCEDIMIENTO CON CURSOR: Alertas de stock mÃƒÂ­nimo
    PROCEDURE sp_alertas_stock_minimo AS
        -- Cursor para productos con stock bajo el mÃƒÂ­nimo
        CURSOR cur_stock_minimo IS
            SELECT p.IdProducto, p.nombreProducto, p.stock_minimo,
                   NVL(s.cantidad, 0) as stock_actual,
                   pr.nombreProveedor, pr.telefono, pr.email
            FROM Productos p
            LEFT JOIN Stock s ON p.IdProducto = s.IdProducto
            INNER JOIN Proveedores pr ON p.IdProveedor = pr.IdProveedor
            WHERE p.activo = 1
            AND NVL(s.cantidad, 0) <= p.stock_minimo
            AND p.stock_minimo > 0
            ORDER BY (NVL(s.cantidad, 0) - p.stock_minimo);

        v_count NUMBER := 0;
    BEGIN
        DBMS_OUTPUT.PUT_LINE('=== ALERTA DE STOCK MÃƒÂNIMO ===');
        DBMS_OUTPUT.PUT_LINE('Productos que requieren reabastecimiento:');
        DBMS_OUTPUT.PUT_LINE('');

        -- Recorre productos con stock mÃƒÂ­nimo
        FOR producto IN cur_stock_minimo LOOP
            v_count := v_count + 1;

            DBMS_OUTPUT.PUT_LINE(v_count || '. ' || producto.nombreProducto);
            DBMS_OUTPUT.PUT_LINE('   Stock actual: ' || producto.stock_actual ||
                               ' | Stock mÃƒÂ­nimo: ' || producto.stock_minimo);
            DBMS_OUTPUT.PUT_LINE('   Proveedor: ' || producto.nombreProveedor ||
                               ' | Tel: ' || producto.telefono);
            DBMS_OUTPUT.PUT_LINE('   Email: ' || NVL(producto.email, 'No disponible'));
            DBMS_OUTPUT.PUT_LINE('');
        END LOOP;

        IF v_count = 0 THEN
            DBMS_OUTPUT.PUT_LINE('No hay productos con stock bajo el mÃƒÂ­nimo.');
        ELSE
            DBMS_OUTPUT.PUT_LINE('Total de productos que requieren reabastecimiento: ' || v_count);
        END IF;

    EXCEPTION
        WHEN OTHERS THEN
            DBMS_OUTPUT.PUT_LINE('Error al generar alertas de stock: ' || SQLERRM);
    END sp_alertas_stock_minimo;

    -- FUNCIÃƒâ€œN CON EXPRESIÃƒâ€œN REGULAR: Buscar clientes por email
    FUNCTION fn_buscar_clientes_por_email(p_patron VARCHAR2) RETURN SYS_REFCURSOR AS
        cur_clientes SYS_REFCURSOR;
    BEGIN
        OPEN cur_clientes FOR
            SELECT IdCliente, nombreCliente, apellidos, email, telefono, tipo_cliente
            FROM Clientes
            WHERE REGEXP_LIKE(email, p_patron, 'i') -- ExpresiÃƒÂ³n regular case-insensitive
            AND activo = 1
            ORDER BY nombreCliente, apellidos;
        RETURN cur_clientes;
    END fn_buscar_clientes_por_email;

    -- FUNCIÃƒâ€œN CON EXPRESIÃƒâ€œN REGULAR: Buscar productos por cÃƒÂ³digo
    FUNCTION fn_buscar_productos_por_codigo(p_patron VARCHAR2) RETURN SYS_REFCURSOR AS
        cur_productos SYS_REFCURSOR;
    BEGIN
        OPEN cur_productos FOR
            SELECT p.IdProducto, p.nombreProducto, p.codigo_producto, p.categoria,
                   p.marca, p.precio, NVL(s.cantidad, 0) as stock
            FROM Productos p
            LEFT JOIN Stock s ON p.IdProducto = s.IdProducto
            WHERE REGEXP_LIKE(p.codigo_producto, p_patron, 'i') -- ExpresiÃƒÂ³n regular para cÃƒÂ³digos
            AND p.activo = 1
            ORDER BY p.codigo_producto;
        RETURN cur_productos;
    END fn_buscar_productos_por_codigo;

    -- FUNCIÃƒâ€œN CON EXPRESIÃƒâ€œN REGULAR: Validar telÃƒÂ©fonos de empleados
    FUNCTION fn_validar_telefonos_empleados RETURN SYS_REFCURSOR AS
        cur_empleados SYS_REFCURSOR;
    BEGIN
        OPEN cur_empleados FOR
            SELECT IdEmpleado, nombreEmpleado, apellidos, telefono,
                   CASE
                       WHEN REGEXP_LIKE(telefono, '^[0-9]{3}-[0-9]{3}-[0-9]{4}$') THEN 'VÃƒÂLIDO'
                       WHEN REGEXP_LIKE(telefono, '^[0-9]{10}$') THEN 'VÃƒÂLIDO (sin formato)'
                       ELSE 'INVÃƒÂLIDO'
                   END as estado_telefono
            FROM Empleados
            WHERE activo = 1
            AND NOT REGEXP_LIKE(telefono, '^[0-9]{3}-[0-9]{3}-[0-9]{4}$|^[0-9]{10}$') -- ExpresiÃƒÂ³n regular para validar formato
            ORDER BY nombreEmpleado, apellidos;
        RETURN cur_empleados;
    END fn_validar_telefonos_empleados;

    -- FUNCIÃƒâ€œN CON EXPRESIÃƒâ€œN REGULAR: Buscar proveedores por RUC
    FUNCTION fn_buscar_proveedores_por_ruc(p_patron VARCHAR2) RETURN SYS_REFCURSOR AS
        cur_proveedores SYS_REFCURSOR;
    BEGIN
        OPEN cur_proveedores FOR
            SELECT IdProveedor, nombreProveedor, ruc, telefono, email, calificacion
            FROM Proveedores
            WHERE REGEXP_LIKE(ruc, p_patron) -- ExpresiÃƒÂ³n regular para RUC
            AND activo = 1
            ORDER BY nombreProveedor;
        RETURN cur_proveedores;
    END fn_buscar_proveedores_por_ruc;

    -- FunciÃƒÂ³n de reporte: Ventas del mes
    FUNCTION fn_reporte_ventas_mes(p_mes NUMBER, p_anio NUMBER) RETURN SYS_REFCURSOR AS
        cur_ventas SYS_REFCURSOR;
    BEGIN
        OPEN cur_ventas FOR
            SELECT TO_CHAR(f.fecha, 'DD/MM/YYYY') as fecha,
                   f.numero_factura,
                   c.nombreCliente || ' ' || c.apellidos as cliente,
                   f.subtotal,
                   f.impuesto,
                   f.total,
                   f.metodo_pago
            FROM Factura f
            INNER JOIN Clientes c ON f.IdCliente = c.IdCliente
            WHERE EXTRACT(MONTH FROM f.fecha) = p_mes
            AND EXTRACT(YEAR FROM f.fecha) = p_anio
            AND f.estado = 'PAGADA'
            ORDER BY f.fecha DESC;
        RETURN cur_ventas;
    END fn_reporte_ventas_mes;

    -- FunciÃƒÂ³n de reporte: Productos mÃƒÂ¡s vendidos
    FUNCTION fn_productos_mas_vendidos(p_limite NUMBER DEFAULT 10) RETURN SYS_REFCURSOR AS
        cur_productos SYS_REFCURSOR;
    BEGIN
        OPEN cur_productos FOR
            SELECT * FROM (
                SELECT p.nombreProducto, p.categoria, p.marca,
                       SUM(df.cantidad) as total_vendido,
                       SUM(df.subtotal) as total_ingresos,
                       COUNT(DISTINCT df.IdFactura) as num_facturas
                FROM detalleFactura df
                INNER JOIN Productos p ON df.IdProducto = p.IdProducto
                INNER JOIN Factura f ON df.IdFactura = f.IdFactura
                WHERE f.estado = 'PAGADA'
                AND f.fecha >= ADD_MONTHS(SYSDATE, -12)
                GROUP BY p.IdProducto, p.nombreProducto, p.categoria, p.marca
                ORDER BY total_vendido DESC
            ) WHERE ROWNUM <= p_limite;
        RETURN cur_productos;
    END fn_productos_mas_vendidos;

    -- FunciÃƒÂ³n de reporte: Clientes con mayor compra
    FUNCTION fn_clientes_mayor_compra RETURN SYS_REFCURSOR AS
        cur_clientes SYS_REFCURSOR;
    BEGIN
        OPEN cur_clientes FOR
            SELECT c.nombreCliente || ' ' || c.apellidos as cliente,
                   c.tipo_cliente,
                   COUNT(f.IdFactura) as num_facturas,
                   SUM(f.total) as total_compras,
                   AVG(f.total) as promedio_compra,
                   MAX(f.fecha) as ultima_compra
            FROM Clientes c
            INNER JOIN Factura f ON c.IdCliente = f.IdCliente
            WHERE f.estado = 'PAGADA'
            AND f.fecha >= ADD_MONTHS(SYSDATE, -12)
            GROUP BY c.IdCliente, c.nombreCliente, c.apellidos, c.tipo_cliente
            HAVING SUM(f.total) > 1000
            ORDER BY total_compras DESC;
        RETURN cur_clientes;
    END fn_clientes_mayor_compra;

    -- ==============================
    -- CRUD Empleados (faltantes)
    -- ==============================
    PROCEDURE sp_insertar_empleado(p_nombre VARCHAR2, p_apellidos VARCHAR2, p_direccion VARCHAR2,
                                   p_telefono VARCHAR2, p_email VARCHAR2, p_cedula VARCHAR2,
                                   p_puesto VARCHAR2, p_salario NUMBER, p_resultado OUT t_resultado) AS
        v_dup NUMBER;
    BEGIN
        SELECT COUNT(*) INTO v_dup FROM Empleados WHERE cedula = p_cedula OR (p_email IS NOT NULL AND email = p_email);
        IF v_dup > 0 THEN
            p_resultado.exito := FALSE;
            p_resultado.mensaje := 'Ya existe un empleado con esa cÃƒÂ©dula o email';
            RETURN;
        END IF;

        INSERT INTO Empleados (nombreEmpleado, apellidos, direccion, telefono, email, cedula, puesto, salario)
        VALUES (p_nombre, p_apellidos, p_direccion, p_telefono, p_email, p_cedula, p_puesto, p_salario);

        COMMIT;
        p_resultado.exito := TRUE;
        p_resultado.mensaje := 'Empleado insertado correctamente';
    EXCEPTION
        WHEN DUP_VAL_ON_INDEX THEN
            ROLLBACK;
            p_resultado.exito := FALSE;
            p_resultado.mensaje := 'Duplicado: cÃƒÂ©dula o email ya existe';
        WHEN OTHERS THEN
            ROLLBACK;
            p_resultado.exito := FALSE;
            p_resultado.mensaje := 'Error al insertar empleado: ' || SQLERRM;
    END sp_insertar_empleado;

    PROCEDURE sp_actualizar_empleado(p_id NUMBER, p_nombre VARCHAR2, p_apellidos VARCHAR2,
                                     p_direccion VARCHAR2, p_telefono VARCHAR2, p_email VARCHAR2,
                                     p_cedula VARCHAR2, p_puesto VARCHAR2, p_salario NUMBER,
                                     p_resultado OUT t_resultado) AS
        v_count NUMBER;
    BEGIN
        SELECT COUNT(*) INTO v_count FROM Empleados WHERE IdEmpleado = p_id;
        IF v_count = 0 THEN
            p_resultado.exito := FALSE;
            p_resultado.mensaje := 'El empleado no existe';
            RETURN;
        END IF;

        UPDATE Empleados
           SET nombreEmpleado = p_nombre,
               apellidos = p_apellidos,
               direccion = p_direccion,
               telefono = p_telefono,
               email = p_email,
               cedula = p_cedula,
               puesto = p_puesto,
               salario = p_salario,
               fecha_modificacion = SYSDATE
         WHERE IdEmpleado = p_id;

        COMMIT;
        p_resultado.exito := TRUE;
        p_resultado.mensaje := 'Empleado actualizado correctamente';
    EXCEPTION
        WHEN DUP_VAL_ON_INDEX THEN
            ROLLBACK;
            p_resultado.exito := FALSE;
            p_resultado.mensaje := 'Duplicado: cÃƒÂ©dula o email ya existe';
        WHEN OTHERS THEN
            ROLLBACK;
            p_resultado.exito := FALSE;
            p_resultado.mensaje := 'Error al actualizar empleado: ' || SQLERRM;
    END sp_actualizar_empleado;

    PROCEDURE sp_eliminar_empleado(p_id NUMBER, p_resultado OUT t_resultado) AS
        v_count NUMBER;
    BEGIN
        -- Evitar eliminar si tiene horarios asociados
        SELECT COUNT(*) INTO v_count FROM Horarios WHERE IdEmpleado = p_id;
        IF v_count > 0 THEN
            p_resultado.exito := FALSE;
            p_resultado.mensaje := 'No se puede eliminar el empleado porque tiene horarios asociados';
            RETURN;
        END IF;

        DELETE FROM Empleados WHERE IdEmpleado = p_id;
        IF SQL%ROWCOUNT = 0 THEN
            p_resultado.exito := FALSE;
            p_resultado.mensaje := 'El empleado no existe';
        ELSE
            COMMIT;
            p_resultado.exito := TRUE;
            p_resultado.mensaje := 'Empleado eliminado correctamente';
        END IF;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            p_resultado.exito := FALSE;
            p_resultado.mensaje := 'Error al eliminar empleado: ' || SQLERRM;
    END sp_eliminar_empleado;

    FUNCTION fn_obtener_empleado(p_id NUMBER) RETURN SYS_REFCURSOR AS
        cur_emp SYS_REFCURSOR;
    BEGIN
        OPEN cur_emp FOR
            SELECT IdEmpleado, nombreEmpleado, apellidos, direccion, telefono, email, cedula, puesto, salario,
                   activo, fecha_ingreso, fecha_modificacion
              FROM Empleados
             WHERE IdEmpleado = p_id;
        RETURN cur_emp;
    END fn_obtener_empleado;

    FUNCTION fn_listar_empleados RETURN SYS_REFCURSOR AS
        cur_emp SYS_REFCURSOR;
    BEGIN
        OPEN cur_emp FOR
            SELECT IdEmpleado, nombreEmpleado, apellidos, direccion, telefono, email, cedula, puesto, salario,
                   activo, fecha_ingreso, fecha_modificacion
              FROM Empleados
             ORDER BY nombreEmpleado, apellidos;
        RETURN cur_emp;
    END fn_listar_empleados;

    -- ==============================
    -- CRUD Proveedores (faltantes)
    -- ==============================
    PROCEDURE sp_insertar_proveedor(p_nombre VARCHAR2, p_direccion VARCHAR2, p_telefono VARCHAR2,
                                    p_email VARCHAR2, p_contacto VARCHAR2, p_ruc VARCHAR2,
                                    p_condiciones_pago VARCHAR2, p_resultado OUT t_resultado) AS
    BEGIN
        INSERT INTO Proveedores (nombreProveedor, direccion, telefono, email, contacto_principal, ruc, condiciones_pago)
        VALUES (p_nombre, p_direccion, p_telefono, p_email, p_contacto, p_ruc, p_condiciones_pago);

        COMMIT;
        p_resultado.exito := TRUE;
        p_resultado.mensaje := 'Proveedor insertado correctamente';
    EXCEPTION
        WHEN DUP_VAL_ON_INDEX THEN
            ROLLBACK;
            p_resultado.exito := FALSE;
            p_resultado.mensaje := 'Duplicado: RUC o email ya existe';
        WHEN OTHERS THEN
            ROLLBACK;
            p_resultado.exito := FALSE;
            p_resultado.mensaje := 'Error al insertar proveedor: ' || SQLERRM;
    END sp_insertar_proveedor;

    PROCEDURE sp_actualizar_proveedor(p_id NUMBER, p_nombre VARCHAR2, p_direccion VARCHAR2,
                                      p_telefono VARCHAR2, p_email VARCHAR2, p_contacto VARCHAR2,
                                      p_ruc VARCHAR2, p_condiciones_pago VARCHAR2, p_resultado OUT t_resultado) AS
        v_count NUMBER;
    BEGIN
        SELECT COUNT(*) INTO v_count FROM Proveedores WHERE IdProveedor = p_id;
        IF v_count = 0 THEN
            p_resultado.exito := FALSE;
            p_resultado.mensaje := 'El proveedor no existe';
            RETURN;
        END IF;

        UPDATE Proveedores
           SET nombreProveedor = p_nombre,
               direccion = p_direccion,
               telefono = p_telefono,
               email = p_email,
               contacto_principal = p_contacto,
               ruc = p_ruc,
               condiciones_pago = p_condiciones_pago,
               fecha_modificacion = SYSDATE
         WHERE IdProveedor = p_id;

        COMMIT;
        p_resultado.exito := TRUE;
        p_resultado.mensaje := 'Proveedor actualizado correctamente';
    EXCEPTION
        WHEN DUP_VAL_ON_INDEX THEN
            ROLLBACK;
            p_resultado.exito := FALSE;
            p_resultado.mensaje := 'Duplicado: RUC o email ya existe';
        WHEN OTHERS THEN
            ROLLBACK;
            p_resultado.exito := FALSE;
            p_resultado.mensaje := 'Error al actualizar proveedor: ' || SQLERRM;
    END sp_actualizar_proveedor;

    PROCEDURE sp_eliminar_proveedor(p_id NUMBER, p_resultado OUT t_resultado) AS
        v_count NUMBER;
    BEGIN
        -- No eliminar si tiene productos asociados
        SELECT COUNT(*) INTO v_count FROM Productos WHERE IdProveedor = p_id;
        IF v_count > 0 THEN
            p_resultado.exito := FALSE;
            p_resultado.mensaje := 'No se puede eliminar: hay productos asociados';
            RETURN;
        END IF;
        -- No eliminar si tiene pedidos asociados
        SELECT COUNT(*) INTO v_count FROM Pedidos WHERE IdProveedor = p_id;
        IF v_count > 0 THEN
            p_resultado.exito := FALSE;
            p_resultado.mensaje := 'No se puede eliminar: hay pedidos asociados';
            RETURN;
        END IF;

        DELETE FROM Proveedores WHERE IdProveedor = p_id;
        IF SQL%ROWCOUNT = 0 THEN
            p_resultado.exito := FALSE;
            p_resultado.mensaje := 'El proveedor no existe';
        ELSE
            COMMIT;
            p_resultado.exito := TRUE;
            p_resultado.mensaje := 'Proveedor eliminado correctamente';
        END IF;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            p_resultado.exito := FALSE;
            p_resultado.mensaje := 'Error al eliminar proveedor: ' || SQLERRM;
    END sp_eliminar_proveedor;

    FUNCTION fn_obtener_proveedor(p_id NUMBER) RETURN SYS_REFCURSOR AS
        cur_prv SYS_REFCURSOR;
    BEGIN
        OPEN cur_prv FOR
            SELECT IdProveedor, nombreProveedor, direccion, telefono, email, contacto_principal, ruc,
                   condiciones_pago, calificacion, activo, fecha_registro, fecha_modificacion
              FROM Proveedores
             WHERE IdProveedor = p_id;
        RETURN cur_prv;
    END fn_obtener_proveedor;

    FUNCTION fn_listar_proveedores RETURN SYS_REFCURSOR AS
        cur_prv SYS_REFCURSOR;
    BEGIN
        OPEN cur_prv FOR
            SELECT IdProveedor, nombreProveedor, direccion, telefono, email, contacto_principal, ruc,
                   condiciones_pago, calificacion, activo, fecha_registro, fecha_modificacion
              FROM Proveedores
             ORDER BY nombreProveedor;
        RETURN cur_prv;
    END fn_listar_proveedores;

END PKG_FERRETERIA;
/

