create trigger TRG_PEDIDOS_NUMERO
    before insert
    on PEDIDOS
    for each row
BEGIN
    -- Genera automÃƒÂ¡ticamente el nÃƒÂºmero de pedido si no se proporciona
    IF :NEW.numero_pedido IS NULL THEN
        :NEW.numero_pedido := 'PED-' || TO_CHAR(SYSDATE, 'YYYYMMDD') || '-' || LPAD(seq_numero_pedido.NEXTVAL, 4, '0');
    END IF;
END;
/

