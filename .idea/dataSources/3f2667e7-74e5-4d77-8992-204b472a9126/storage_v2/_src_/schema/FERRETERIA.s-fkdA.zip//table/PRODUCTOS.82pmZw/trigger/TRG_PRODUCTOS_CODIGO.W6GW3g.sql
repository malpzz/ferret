create trigger TRG_PRODUCTOS_CODIGO
    before insert
    on PRODUCTOS
    for each row
BEGIN
    -- Si no se proporciona cÃƒÂ³digo de producto, genera uno automÃƒÂ¡tico
    IF :NEW.codigo_producto IS NULL THEN
        :NEW.codigo_producto := 'PROD-' || TO_CHAR(SYSDATE, 'YYYYMMDD') || '-' || LPAD(seq_numero_pedido.NEXTVAL, 4, '0');
    END IF;
END;
/

