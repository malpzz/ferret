create trigger TRG_EMPLEADOS_FECHA_MOD
    before update
    on EMPLEADOS
    for each row
BEGIN
    -- Actualiza automÃƒÂ¡ticamente la fecha de modificaciÃƒÂ³n al momento de actualizar un empleado
    :NEW.fecha_modificacion := SYSDATE;
END;
/

