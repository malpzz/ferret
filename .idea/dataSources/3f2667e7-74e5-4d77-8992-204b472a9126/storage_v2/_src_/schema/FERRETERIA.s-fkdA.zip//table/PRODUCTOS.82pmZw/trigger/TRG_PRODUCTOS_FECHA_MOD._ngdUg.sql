create trigger TRG_PRODUCTOS_FECHA_MOD
    before update
    on PRODUCTOS
    for each row
BEGIN
    -- Actualiza automÃƒÂ¡ticamente la fecha de modificaciÃƒÂ³n al momento de actualizar un producto
    :NEW.fecha_modificacion := SYSDATE;
END;
/

