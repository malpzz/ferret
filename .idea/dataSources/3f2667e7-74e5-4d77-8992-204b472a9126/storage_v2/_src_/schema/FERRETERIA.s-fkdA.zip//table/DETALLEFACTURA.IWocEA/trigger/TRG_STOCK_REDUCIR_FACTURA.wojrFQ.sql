create trigger TRG_STOCK_REDUCIR_FACTURA
    after insert
    on DETALLEFACTURA
    for each row
DECLARE
    v_stock_actual NUMBER;
BEGIN
    -- Obtiene el stock actual del producto
    SELECT cantidad INTO v_stock_actual
    FROM Stock
    WHERE IdProducto = :NEW.IdProducto;

    -- Verifica que hay suficiente stock
    IF v_stock_actual < :NEW.cantidad THEN
        RAISE_APPLICATION_ERROR(-20005, 'Stock insuficiente para el producto. Stock disponible: ' || v_stock_actual);
    END IF;

    -- Reduce el stock
    UPDATE Stock
    SET cantidad = cantidad - :NEW.cantidad,
        fecha_ultimo_movimiento = SYSDATE
    WHERE IdProducto = :NEW.IdProducto;
END;
/

