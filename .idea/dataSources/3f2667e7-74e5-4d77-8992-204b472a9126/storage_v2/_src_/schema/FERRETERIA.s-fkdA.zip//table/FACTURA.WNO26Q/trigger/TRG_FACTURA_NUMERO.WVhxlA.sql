create trigger TRG_FACTURA_NUMERO
    before insert
    on FACTURA
    for each row
BEGIN
    -- Genera automÃƒÂ¡ticamente el nÃƒÂºmero de factura si no se proporciona
    IF :NEW.numero_factura IS NULL THEN
        :NEW.numero_factura := 'FAC-' || TO_CHAR(SYSDATE, 'YYYYMMDD') || '-' || LPAD(seq_numero_factura.NEXTVAL, 4, '0');
    END IF;
END;
/

