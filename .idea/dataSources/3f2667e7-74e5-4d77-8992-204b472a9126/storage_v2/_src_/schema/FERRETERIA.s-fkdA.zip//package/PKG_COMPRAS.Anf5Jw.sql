create PACKAGE PKG_COMPRAS AS
    FUNCTION fn_listar_pedidos RETURN SYS_REFCURSOR;
    FUNCTION fn_obtener_pedido(p_id NUMBER) RETURN SYS_REFCURSOR;
    PROCEDURE sp_insertar_pedido(
        p_numero VARCHAR2,
        p_fecha DATE,
        p_id_proveedor NUMBER,
        p_estado VARCHAR2 DEFAULT 'PENDIENTE',
        p_fecha_entrega DATE DEFAULT NULL,
        p_descripcion VARCHAR2 DEFAULT NULL,
        p_observaciones VARCHAR2 DEFAULT NULL,
        p_id_pedido OUT NUMBER
    );
    PROCEDURE sp_agregar_detalle_pedido(
        p_id_pedido NUMBER,
        p_id_producto NUMBER,
        p_precio NUMBER,
        p_cantidad NUMBER
    );
    PROCEDURE sp_actualizar_estado_pedido(p_id NUMBER, p_estado VARCHAR2);
END PKG_COMPRAS;
/

