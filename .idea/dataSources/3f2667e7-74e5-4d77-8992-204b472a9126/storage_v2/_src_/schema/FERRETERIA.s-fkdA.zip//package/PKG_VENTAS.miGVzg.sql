create PACKAGE PKG_VENTAS AS
    FUNCTION fn_listar_facturas RETURN SYS_REFCURSOR;
    FUNCTION fn_obtener_factura(p_id NUMBER) RETURN SYS_REFCURSOR;
    PROCEDURE sp_insertar_factura(
        p_numero VARCHAR2,
        p_fecha DATE,
        p_id_cliente NUMBER,
        p_metodo_pago VARCHAR2 DEFAULT 'EFECTIVO',
        p_estado VARCHAR2 DEFAULT 'PENDIENTE',
        p_observaciones VARCHAR2 DEFAULT NULL,
        p_id_factura OUT NUMBER
    );
    PROCEDURE sp_agregar_detalle_factura(
        p_id_factura NUMBER,
        p_id_producto NUMBER,
        p_precio NUMBER,
        p_cantidad NUMBER,
        p_descuento NUMBER DEFAULT 0
    );
    PROCEDURE sp_anular_factura(p_id NUMBER);
END PKG_VENTAS;
/

