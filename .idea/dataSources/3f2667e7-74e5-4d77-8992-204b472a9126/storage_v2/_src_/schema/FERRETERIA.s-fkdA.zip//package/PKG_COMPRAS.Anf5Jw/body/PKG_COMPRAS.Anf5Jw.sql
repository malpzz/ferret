create PACKAGE BODY PKG_COMPRAS AS
    FUNCTION fn_listar_pedidos RETURN SYS_REFCURSOR AS
        cur SYS_REFCURSOR;
    BEGIN
        OPEN cur FOR
            SELECT p.IdPedido, p.numero_pedido, p.fecha, p.total, p.estado,
                   p.fecha_entrega_esperada, pr.nombreProveedor
            FROM Pedidos p JOIN Proveedores pr ON pr.IdProveedor = p.IdProveedor
            ORDER BY p.fecha DESC, p.IdPedido DESC;
        RETURN cur;
    END;

    FUNCTION fn_obtener_pedido(p_id NUMBER) RETURN SYS_REFCURSOR AS
        cur SYS_REFCURSOR;
    BEGIN
        OPEN cur FOR
            SELECT p.*, pr.nombreProveedor, pr.email
            FROM Pedidos p JOIN Proveedores pr ON pr.IdProveedor = p.IdProveedor
            WHERE p.IdPedido = p_id;
        RETURN cur;
    END;

    PROCEDURE sp_insertar_pedido(
        p_numero VARCHAR2,
        p_fecha DATE,
        p_id_proveedor NUMBER,
        p_estado VARCHAR2,
        p_fecha_entrega DATE,
        p_descripcion VARCHAR2,
        p_observaciones VARCHAR2,
        p_id_pedido OUT NUMBER
    ) AS
    BEGIN
        INSERT INTO Pedidos (numero_pedido, fecha, IdProveedor, estado, fecha_entrega_esperada, descripcion, observaciones)
        VALUES (p_numero, NVL(p_fecha, SYSDATE), p_id_proveedor, p_estado, p_fecha_entrega, p_descripcion, p_observaciones)
        RETURNING IdPedido INTO p_id_pedido;
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE;
    END;

    PROCEDURE sp_agregar_detalle_pedido(
        p_id_pedido NUMBER,
        p_id_producto NUMBER,
        p_precio NUMBER,
        p_cantidad NUMBER
    ) AS
    BEGIN
        INSERT INTO detallePedido (IdPedido, IdProducto, precioUni, cantidad)
        VALUES (p_id_pedido, p_id_producto, p_precio, p_cantidad);
        -- trg_pedidos_actualizar_total recalcula total
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE;
    END;

    PROCEDURE sp_actualizar_estado_pedido(p_id NUMBER, p_estado VARCHAR2) AS
    BEGIN
        UPDATE Pedidos SET estado = p_estado, fecha_modificacion = SYSDATE
        WHERE IdPedido = p_id;
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE;
    END;
END PKG_COMPRAS;
/

