create trigger TRG_STOCK_ACTUALIZAR_PEDIDO
    after update
    on PEDIDOS
    for each row
    when (NEW.estado = 'RECIBIDO' AND OLD.estado != 'RECIBIDO')
DECLARE
    -- Cursor para obtener todos los productos del pedido recibido
    CURSOR cur_productos_pedido IS
        SELECT IdProducto, cantidad
        FROM detallePedido
        WHERE IdPedido = :NEW.IdPedido;
BEGIN
    -- Recorre todos los productos del pedido y actualiza el stock
    FOR producto IN cur_productos_pedido LOOP
        -- Actualiza el stock del producto aumentando la cantidad recibida
        UPDATE Stock
        SET cantidad = cantidad + producto.cantidad,
            fecha_ultimo_movimiento = SYSDATE
        WHERE IdProducto = producto.IdProducto;

        -- Si no existe registro de stock para el producto, lo crea
        IF SQL%ROWCOUNT = 0 THEN
            INSERT INTO Stock (cantidad, IdProducto, fecha_ultimo_movimiento)
            VALUES (producto.cantidad, producto.IdProducto, SYSDATE);
        END IF;
    END LOOP;
END;
/

