create PROCEDURE sp_backup_diario AS
BEGIN
    -- Este procedimiento ejecutarÃƒÂ­a respaldos automÃƒÂ¡ticos
    DBMS_OUTPUT.PUT_LINE('Ejecutando respaldo diario - ' || TO_CHAR(SYSDATE, 'DD/MM/YYYY HH24:MI:SS'));

    -- AquÃƒÂ­ irÃƒÂ­an las instrucciones de respaldo especÃƒÂ­ficas
    -- Por ejemplo, exportar datos crÃƒÂ­ticos o crear copias de seguridad

    DBMS_OUTPUT.PUT_LINE('Respaldo completado exitosamente');
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Error durante el respaldo: ' || SQLERRM);
END;
/

