create trigger TRG_CLIENTES_FECHA_MOD
    before update
    on CLIENTES
    for each row
BEGIN
    -- Actualiza automÃƒÂ¡ticamente la fecha de modificaciÃƒÂ³n al momento de actualizar un cliente
    :NEW.fecha_modificacion := SYSDATE;
END;
/

